import 'package:app_live3_direct/widgets/RowLetter.dart';
import 'package:flutter/material.dart';


class HomePage extends StatefulWidget {
  const HomePage({ Key? key }) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Anlyse Voyelle"),
      ),
      // ignore: prefer_const_literals_to_create_immutables
      body:Column(children: [
        const RowLetter(colorRow: Colors.purple, letter: "A", textOcurrrences: ": X occurences"),
        const RowLetter(colorRow: Colors.cyan, letter: "E", textOcurrrences: ": X occurences"),
        const RowLetter(colorRow: Colors.red, letter: "I", textOcurrrences: ": X occurences"),
        const RowLetter(colorRow: Colors.green, letter: "O", textOcurrrences: ": X occurences"),
        const RowLetter(colorRow: Colors.orange, letter: "U", textOcurrrences: ": X occurences"),
        const RowLetter(colorRow: Colors.blue, letter: "Y", textOcurrrences: ": X occurences"),
        const RowLetter(colorRow: Colors.black, letter: "Consonnes", textOcurrrences: ": X occurences")
      ])
    );
   

  }
}